//Ethan Hammer

class Main {
  public static void main(String[] args) {
    Calculator myCalculator = new Calculator();
    myCalculator.start();
  }
}